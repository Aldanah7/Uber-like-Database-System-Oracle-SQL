
-- Drop Payment table
DROP TABLE Payment;

-- Drop Rating table
DROP TABLE Rating;

-- Drop Trip table
DROP TABLE Trip;

-- Drop Driver table
DROP TABLE Driver;

-- Drop Customer table
DROP TABLE Customer;